<a href="/">
    <svg class="mx-auto" width="80" height="67" viewBox="0 0 80 67" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="39.5" cy="17.5" r="15.5" stroke="black" stroke-width="2"/>
        <circle cx="39.5" cy="50.5" r="15.5" stroke="black" stroke-width="2"/>
        <line y1="34" x2="80" y2="34" stroke="black" stroke-width="2"/>
        <path d="M23 67V16.5141L6 0V67H23Z" fill="black"/>
        <path d="M56 67V16.5141L73 0V67H56Z" fill="black"/>
    </svg>
</a><?php /**PATH /Applications/MAMP/htdocs/minth/resources/views/components/application-logo.blade.php ENDPATH**/ ?>