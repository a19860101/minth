<?php $__env->startSection('main'); ?>
<section class="relative h-full bg-center bg-no-repeat bg-cover" style="background-image:url('/images/bg.png')">
    <div class="flex items-start h-fit max-w-screen-xl w-10/12 absolute inset-0 m-auto p-32">
        
        <h2 class="text-2xl absolute text-center w-full top-0 left-0 text-[#013565]">相關認證</h2>
        <div class="flex flex-wrap">
            <div class="w-1/3 p-4">
                <img src="https://picsum.photos/id/26/500" alt="">
            </div>
            <div class="w-1/3 p-4">
                <img src="https://picsum.photos/id/26/500" alt="">
            </div>
            <div class="w-1/3 p-4">
                <img src="https://picsum.photos/id/26/500" alt="">
            </div>
            <div class="w-1/3 p-4">
                <img src="https://picsum.photos/id/26/500" alt="">
            </div>
            <div class="w-1/3 p-4">
                <img src="https://picsum.photos/id/26/500" alt="">
            </div>
            <div class="w-1/3 p-4">
                <img src="https://picsum.photos/id/26/500" alt="">
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/minth/resources/views/certified.blade.php ENDPATH**/ ?>