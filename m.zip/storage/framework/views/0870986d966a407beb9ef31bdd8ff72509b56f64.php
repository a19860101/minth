
            <p class="text-center">Powered by <a class="link-default" href="https://nova.laravel.com">Laravel Nova</a> · v<?php echo $version; ?></p>
            <p class="text-center">&copy; <?php echo $year; ?> Laravel LLC &middot; by Taylor Otwell and David Hemphill.</p>
        <?php /**PATH /Applications/MAMP/htdocs/minth/storage/framework/views/d840814509a1a54794a2b04b51f0374485e574b3.blade.php ENDPATH**/ ?>