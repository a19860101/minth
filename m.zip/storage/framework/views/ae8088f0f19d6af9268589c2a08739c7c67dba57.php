<?php $__env->startSection('main'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/minth/resources/views/product/index.blade.php ENDPATH**/ ?>