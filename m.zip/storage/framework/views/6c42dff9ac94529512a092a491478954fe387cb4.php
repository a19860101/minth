<?php $__env->startSection('main'); ?>
<section>
    <div class="w-full h-[300px]">
        <img src="/images/news.jpg" alt="" class="w-full h-full object-cover">
    </div>
    <div>
        <h1 class="text-2xl text-[#013565] text-center py-8">最新消息</h1>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/minth/resources/views/posts/index.blade.php ENDPATH**/ ?>