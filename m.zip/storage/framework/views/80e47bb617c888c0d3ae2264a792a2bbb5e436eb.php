<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
<style>
    /* D6E6F5 */
    .img-shadow {
        box-shadow: 20px 20px 0px rgb(214 230 245 / .9)
    }
    .slick-next:before, .slick-prev:before {color: #013565;}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<section class="relative h-full bg-center bg-no-repeat bg-cover" style="background-image:url('/images/bg-2.png')">
    <div class="bg-white/50 border border-[#3175B2] rounded-[66px] flex items-start h-fit max-w-screen-xl w-11/12 absolute inset-0 m-auto px-20 py-32 shadow-md shadow-[#BFD7ED]">
        <h2 class="text-2xl absolute text-center w-full top-[-100px] left-0 text-[#013565]">設備介紹</h2>
        
        <div class="slider w-full">
            <div class="mx-2">
                <a href="#">
                    <img src="https://picsum.photos/id/98/200" alt="" class="w-full">
                </a>
                <div class="text-center mt-4">Title</div>
            </div>
            <div class="mx-2">
                <a href="#">
                    <img src="https://picsum.photos/id/18/200" alt="" class="w-full">
                </a>
                <div class="text-center mt-4">Title</div>
            </div>
            <div class="mx-2">
                <a href="#">
                    <img src="https://picsum.photos/id/28/200" alt="" class="w-full">
                </a>
                <div class="text-center mt-4">Title</div>
            </div>
            <div class="mx-2">
                <a href="#">
                    <img src="https://picsum.photos/id/38/200" alt="" class="w-full">
                </a>
                <div class="text-center mt-4">Title</div>
            </div>
            <div class="mx-2">
                <a href="#">
                    <img src="https://picsum.photos/id/48/200" alt="" class="w-full">
                </a>
                <div class="text-center mt-4">Title</div>
            </div>
            
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<script>
    $(function(){
        $('.slider').slick({
            slidesToShow:1,
            centerMode: true,
            centerPadding: '250px',
            infinite: false
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/minth/resources/views/equipment/index.blade.php ENDPATH**/ ?>